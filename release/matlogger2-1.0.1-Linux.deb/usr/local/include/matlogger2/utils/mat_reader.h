#include <string>
#include <Eigen/Dense>

namespace XBot
{
    
    class MatReader
    {
        
    public:
        
        MatReader(std::string mat_file);
        
        ~MatReader();
        
        
    private:
        
    };
    
}
